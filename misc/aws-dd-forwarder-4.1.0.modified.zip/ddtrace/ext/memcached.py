CMD = "memcached.command"
DBMS_NAME = "memcached"
SERVICE = "memcached"
QUERY = "memcached.query"
